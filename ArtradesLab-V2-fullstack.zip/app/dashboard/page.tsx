import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  const user = await prisma.user.findUnique({
    where: { id: session.sub },
    select: { name: true, email: true, role: true, demoAccount: true }
  });
  if (!user) redirect("/login");
  return <main className="simple-dashboard">
    <header className="dash-header"><div className="brand"><div className="brand-mark">A</div><div><b>Artrades<span>Lab</span></b><small>TRADING TECHNOLOGY</small></div></div><form action="/api/auth/logout" method="post"><button className="outline-btn" formAction={undefined} onClick={async()=>{"use client";}}> </button></form><Link className="outline-btn" href="/">Open trading terminal</Link></header>
    <section className="dash-content"><span className="eyebrow">ACCOUNT OVERVIEW</span><h1>Welcome, {user.name}</h1><p>{user.email}</p>
      <div className="dash-cards"><div className="stat"><span>Demo balance</span><b>${Number(user.demoAccount?.balance ?? 0).toFixed(2)}</b><small>Virtual funds · USD</small></div><div className="stat"><span>Account type</span><b>Demo workspace</b><small>Live market data, virtual trading</small></div><div className="stat"><span>Access level</span><b>{user.role}</b><small>Account permissions</small></div></div>
      <div className="notice"><b>Real-money trading is not enabled.</b><p>Live trading requires an approved broker relationship, regulatory review, verified account eligibility and secure execution integration. Your demo balance has no cash value.</p></div>
      {user.role==="ADMIN"&&<Link className="primary-btn" href="/admin">Open admin console</Link>}
    </section>
  </main>;
}
