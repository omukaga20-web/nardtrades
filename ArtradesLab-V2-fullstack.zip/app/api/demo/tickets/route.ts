import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

const schema = z.object({
  market: z.string().min(1).max(40),
  direction: z.enum(["UP", "DOWN"]),
  stake: z.number().finite().positive().max(100000)
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Please sign in first." }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid demo ticket details." }, { status: 400 });

  try {
    const result = await prisma.$transaction(async tx => {
      const account = await tx.demoAccount.findUnique({ where: { userId: session.sub } });
      if (!account || Number(account.balance) < parsed.data.stake) throw new Error("INSUFFICIENT_DEMO_BALANCE");
      const updated = await tx.demoAccount.update({
        where: { id: account.id },
        data: { balance: { decrement: parsed.data.stake } }
      });
      const ticket = await tx.demoTicket.create({
        data: { userId: session.sub, market: parsed.data.market, direction: parsed.data.direction, stake: parsed.data.stake }
      });
      return { balance: updated.balance, ticket };
    });
    return NextResponse.json({ ok: true, balance: result.balance, ticket: result.ticket }, { status: 201 });
  } catch (e) {
    if (e instanceof Error && e.message === "INSUFFICIENT_DEMO_BALANCE") {
      return NextResponse.json({ error: "Insufficient demo balance." }, { status: 400 });
    }
    return NextResponse.json({ error: "Could not create demo ticket." }, { status: 500 });
  }
}
