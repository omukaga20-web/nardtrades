import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const [user, tickets] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.sub },
      select: { id: true, name: true, email: true, role: true, createdAt: true, demoAccount: true }
    }),
    prisma.demoTicket.findMany({
      where: { userId: session.sub },
      orderBy: { createdAt: "desc" },
      take: 30,
      select: { id: true, market: true, direction: true, stake: true, status: true, createdAt: true }
    })
  ]);
  if (!user) return NextResponse.json({ error: "Account not found" }, { status: 404 });
  return NextResponse.json({ user, tickets });
}
