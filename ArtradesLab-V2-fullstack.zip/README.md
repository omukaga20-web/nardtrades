# ArtradesLab V2

Full-stack starter with PostgreSQL/Prisma, password-based registration/login, httpOnly signed session cookies, per-user demo balances, demo ticket API, account dashboard, and role-protected admin views.

## Requirements
- Node.js 20+
- PostgreSQL database
- npm

## Setup
1. `npm install`
2. Copy `.env.example` to `.env.local` and configure `DATABASE_URL` and a strong random `SESSION_SECRET`.
3. `npx prisma generate`
4. `npx prisma db push` (or create a migration with `npx prisma migrate dev --name init`)
5. `npm run dev`
6. Open `http://localhost:3000`

## Routes
- `/` trading terminal
- `/register` account registration (creates a USD 10,000 virtual demo account)
- `/login` sign in
- `/dashboard` protected account dashboard
- `/admin` role-protected user overview

## API
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/account`
- `POST /api/demo/tickets`
- `GET /api/admin/users` (ADMIN only)

## First admin
Register your account, then promote it to ADMIN using a trusted database console:
`UPDATE "User" SET role = 'ADMIN' WHERE email = 'your-email@example.com';`
Do not create a public admin signup endpoint.

## Deployment
Deploy to a Node-compatible host such as Vercel. Provision managed PostgreSQL, set the environment variables in the host dashboard, and deploy. Ensure the production build runs Prisma generation and that migrations are applied before serving traffic.

## Important boundaries
- The demo account and ticket records are virtual and are not broker orders.
- Demo ticket creation deducts virtual stake but does not settle a win/loss.
- Public market-data feed code is in the V1 terminal page. Verify the current official Deriv WebSocket endpoint and available symbols against the Deriv developer documentation before production use.
- Real-money account creation, custody, deposits, withdrawals, and execution are intentionally not implemented. They require an approved broker/partner arrangement, applicable regulatory authorization, KYC/AML, safeguarding, and jurisdiction-specific legal review. Never represent internal demo balances as customer funds.
- Add email verification, password reset, CSRF strategy, rate limiting, monitoring, security review, and automated tests before public launch.
