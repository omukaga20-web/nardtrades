import Reveal from "../components/Reveal";
import { card } from "../lib/ui";
const steps = [
  { t: "Sign up", d: "Create a free account with your email." },
  { t: "Fund your account", d: "Add funds with a supported payment method. [PLACEHOLDER: payment methods]" },
  { t: "Trade", d: "Pick a market, place a trade and review the result." },
];
export default function Steps() {
  return (
    <section id="how" aria-labelledby="s-h" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16">
      <h2 id="s-h" className="mb-8 text-2xl font-bold sm:text-3xl">Three steps to your first trade</h2>
      <ol className="grid gap-4 md:grid-cols-3">
        {steps.map((s, n) => (
          <li key={s.t}><Reveal delay={n * 0.08}><div className={`${card} h-full`}>
            <span className="mb-3 grid h-9 w-9 place-items-center rounded-full bg-cyan-400 font-bold text-navy" aria-hidden>{n + 1}</span>
            <h3 className="font-semibold">{s.t}</h3><p className="mt-1 text-sm text-slate-300">{s.d}</p>
          </div></Reveal></li>
        ))}
      </ol>
    </section>
  );
}
