import { STATS } from "../lib/config";
type S = { label: string; value: string };
export default function Stats({ items = STATS }: { items?: S[] }) {
  return (
    <section aria-label="Platform statistics" className="mx-auto max-w-6xl px-4 py-10">
      <dl className="grid grid-cols-2 gap-4 rounded-2xl border border-white/10 bg-surface p-6 text-center md:grid-cols-4">
        {items.map((s) => (<div key={s.label}><dd className="text-2xl font-bold text-cyan-400 sm:text-3xl">{s.value}</dd><dt className="mt-1 text-sm text-slate-300">{s.label}</dt></div>))}
      </dl>
    </section>
  );
}
