import { Button } from "../components/Button";
import { BRAND } from "../lib/config";
export default function AppSection() {
  return (
    <section id="support" aria-labelledby="a-h" className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-16 md:grid-cols-2">
      <div>
        <h2 id="a-h" className="text-2xl font-bold sm:text-3xl">Take {BRAND} with you</h2>
        <p className="mt-2 text-slate-300">A mobile app is planned. The store buttons will activate once it's published.</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button variant="outline" disabled aria-label="App Store, coming soon">App Store (soon)</Button>
          <Button variant="outline" disabled aria-label="Google Play, coming soon">Google Play (soon)</Button>
        </div>
      </div>
      <div className="mx-auto h-80 w-44 rounded-[2rem] border-4 border-white/15 bg-surface p-3" aria-hidden>
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-white/20" />
        <div className="h-24 rounded-xl bg-cyan-400/15" /><div className="mt-3 h-4 w-2/3 rounded bg-white/10" /><div className="mt-2 h-4 w-1/2 rounded bg-white/10" /><div className="mt-5 h-10 rounded-xl bg-cyan-400/80" />
      </div>
    </section>
  );
}
