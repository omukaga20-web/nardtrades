import { Globe2, Headphones, Receipt, ShieldCheck, Smartphone, Zap } from "lucide-react";
import Reveal from "../components/Reveal";
import { card } from "../lib/ui";
const items = [
  { i: Zap, t: "Fast", d: "A responsive trading screen that keeps up with you." },
  { i: ShieldCheck, t: "Secure", d: "Protected sign-in and encrypted connections." },
  { i: Globe2, t: "Many markets", d: "Forex, crypto, stocks and commodities to practise on." },
  { i: Receipt, t: "Transparent fees", d: "Every fee is listed up front. [PLACEHOLDER: fee schedule]" },
  { i: Smartphone, t: "Responsive", d: "Works on phones, tablets and desktops." },
  { i: Headphones, t: "Support", d: "Help when you need it. [PLACEHOLDER: support hours]" },
];
export default function Features() {
  return (
    <section aria-labelledby="f-h" className="mx-auto max-w-6xl px-4 py-16">
      <h2 id="f-h" className="mb-8 text-2xl font-bold sm:text-3xl">Built for learning the markets</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(({ i: Icon, t, d }, n) => (
          <Reveal key={t} delay={n * 0.05}><div className={`${card} h-full`}><Icon className="mb-3 h-6 w-6 text-cyan-400" aria-hidden /><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-slate-300">{d}</p></div></Reveal>
        ))}
      </div>
    </section>
  );
}
