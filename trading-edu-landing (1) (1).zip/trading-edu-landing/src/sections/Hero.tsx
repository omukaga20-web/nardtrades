import { BadgeDollarSign, Globe2, ShieldCheck, Zap } from "lucide-react";
import { LinkButton } from "../components/Button";
import Reveal from "../components/Reveal";
import { COPY } from "../lib/config";
import { useMarket } from "../lib/marketFeed";
const chips = [{ i: Zap, t: "Fast execution" }, { i: ShieldCheck, t: "Secure login" }, { i: Globe2, t: "100+ markets" }, { i: BadgeDollarSign, t: "No deposit fees" }];
export default function Hero() {
  const live = useMarket().status === "live"; // badge claims LIVE only while real data is flowing
  return (
    <section className="mx-auto max-w-4xl px-4 pb-14 pt-16 text-center sm:pt-24">
      <Reveal>
        <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-sm text-cyan-300">
          <span className={`h-2 w-2 rounded-full ${live ? "animate-pulse bg-cyan-400 motion-reduce:animate-none" : "bg-slate-500"}`} aria-hidden />
          {live ? "LIVE MARKET DATA" : "MARKET DATA"}
        </span>
        <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-6xl">Trade the markets with Confidence</h1>
        <p className="mx-auto mt-4 max-w-xl text-lg text-slate-300">{COPY.sub}</p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <LinkButton to="#markets" className="px-6 py-3 text-base">{COPY.heroCta}</LinkButton>
          <LinkButton to="#how" variant="outline" className="px-6 py-3 text-base">See How It Works</LinkButton>
        </div>
        <ul className="mt-10 flex flex-wrap justify-center gap-3">
          {chips.map(({ i: Icon, t }) => (<li key={t} className="flex items-center gap-2 rounded-full border border-white/10 bg-surface px-4 py-2 text-sm text-slate-200"><Icon className="h-4 w-4 text-cyan-400" aria-hidden />{t}</li>))}
        </ul>
      </Reveal>
    </section>
  );
}
