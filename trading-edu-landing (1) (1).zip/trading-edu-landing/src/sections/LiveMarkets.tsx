import { useState } from "react";
import LiveBadge from "../components/LiveBadge";
import LiveChart from "../components/LiveChart";
import Reveal from "../components/Reveal";
import { MARKETS, useMarket } from "../lib/marketFeed";
import { card, fmt } from "../lib/ui";
const sign = (n: number) => (n >= 0 ? "+" : "−");
export default function LiveMarkets() {
  const { quotes, status, error } = useMarket();
  const [sym, setSym] = useState(MARKETS[0].symbol);
  const [mode, setMode] = useState<"candle" | "line">("candle");
  const m = MARKETS.find((x) => x.symbol === sym)!; const q = quotes[sym];
  const pill = (on: boolean) => `rounded-lg px-3 py-1.5 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 ${on ? "bg-cyan-400 font-semibold text-navy" : "text-slate-300 hover:bg-white/10"}`;
  return (
    <section id="markets" aria-labelledby="lm-h" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h2 id="lm-h" className="text-2xl font-bold sm:text-3xl">Live markets</h2>
        <LiveBadge />
      </div>
      {error && !Object.keys(quotes).length && <p role="alert" className="mb-4 rounded-xl bg-amber-400/10 p-4 text-sm text-amber-300">{error} Prices will appear when the connection is restored.</p>}
      {status !== "live" && Object.keys(quotes).length > 0 && <p className="mb-4 rounded-xl bg-amber-400/10 p-3 text-sm text-amber-300">Prices below are not updating right now and may be out of date.</p>}
      <Reveal className="grid gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div className={`${card} overflow-x-auto p-0`}>
          <table className="w-full min-w-[380px] text-left text-sm">
            <caption className="sr-only">Live market prices, 24 hour movement</caption>
            <thead className="text-xs text-slate-400"><tr><th className="p-3 font-medium">Market</th><th className="p-3 text-right font-medium">Price</th><th className="p-3 text-right font-medium">Movement 24h</th><th className="p-3 text-right font-medium">Change 24h</th></tr></thead>
            <tbody>
              {MARKETS.map((mk) => {
                const k = quotes[mk.symbol]; const chg = k ? k.price - k.open : 0; const pct = k ? (chg / k.open) * 100 : 0; const up = chg >= 0;
                return (
                  <tr key={mk.symbol} className={`border-t border-white/10 ${mk.symbol === sym ? "bg-cyan-400/10" : ""}`}>
                    <td className="p-3"><button onClick={() => setSym(mk.symbol)} aria-pressed={mk.symbol === sym} className="rounded text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"><span className="font-semibold">{mk.name}</span><span className="block text-xs text-slate-400">{mk.pair}</span></button></td>
                    {k ? <>
                      <td className="p-3 text-right tabular-nums">{fmt(k.price, mk.dec)}</td>
                      <td className={`p-3 text-right tabular-nums ${up ? "text-cyan-400" : "text-red-400"}`}>{up ? "▲" : "▼"} {fmt(Math.abs(chg), mk.dec)}</td>
                      <td className={`p-3 text-right tabular-nums ${up ? "text-cyan-400" : "text-red-400"}`}>{sign(pct)}{Math.abs(pct).toFixed(2)}%</td>
                    </> : <td colSpan={3} className="p-3"><div className="h-5 animate-pulse rounded bg-white/10" /></td>}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className={card}>
          <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
            <div><h3 className="font-semibold">{m.name} <span className="font-normal text-slate-400">{m.pair}</span></h3>
              <p className="text-2xl font-bold tabular-nums">{q ? fmt(q.price, m.dec) : "—"}</p>
              {q && <p className="text-xs text-slate-400">24h high {fmt(q.high, m.dec)} · low {fmt(q.low, m.dec)}</p>}</div>
            <div className="flex gap-2" role="group" aria-label="Chart type">
              <button aria-pressed={mode === "candle"} className={pill(mode === "candle")} onClick={() => setMode("candle")}>Candles</button>
              <button aria-pressed={mode === "line"} className={pill(mode === "line")} onClick={() => setMode("line")}>Line</button>
            </div>
          </div>
          <LiveChart symbol={sym} mode={mode} />
          <p className="mt-3 text-xs text-slate-400">Chart: 1-minute candles. Source: Binance public market data (crypto spot pairs). Prices are indicative and not an offer to trade.</p>
        </div>
      </Reveal>
    </section>
  );
}
