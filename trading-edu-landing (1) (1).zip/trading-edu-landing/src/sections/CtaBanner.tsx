import { LinkButton } from "../components/Button";
import Reveal from "../components/Reveal";
import { COPY } from "../lib/config";
export default function CtaBanner() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-16">
      <Reveal><div className="rounded-2xl border border-cyan-400/30 bg-gradient-to-br from-surface to-blue-950/40 p-8 text-center sm:p-12">
        <h2 className="text-2xl font-bold sm:text-3xl">{COPY.banner}</h2>
        <p className="mx-auto mt-2 max-w-md text-slate-300">{COPY.bannerSub}</p>
        <LinkButton to="/register" className="mt-6 px-6 py-3 text-base">{COPY.cta}</LinkButton>
      </div></Reveal>
    </section>
  );
}
