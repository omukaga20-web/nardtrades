// Every value you must fill in lives here. Search the repo for [PLACEHOLDER].
export const MODE: "demo" | "live" = import.meta.env.VITE_MODE === "live" ? "live" : "demo";
export const POST_AUTH_URL = (import.meta.env.VITE_POST_AUTH_URL as string | undefined) ?? "/";
export const BRAND = "Pipnex";
export const REGULATOR_LINE = "[REGULATOR + LICENSE NO.]";
export const CONTACT_EMAIL = "[PLACEHOLDER: support email]";
export const STATS = [
  { label: "Registered learners", value: "[PLACEHOLDER]" },
  { label: "Trades placed", value: "[PLACEHOLDER]" },
  { label: "Countries served", value: "[PLACEHOLDER]" },
  { label: "Support hours", value: "[PLACEHOLDER]" },
];
export type Testimonial = { name: string; location: string; quote: string };
// Add real, consented reviews only. Empty = the section is hidden.
export const TESTIMONIALS: Testimonial[] = [];
export const RISK = "Trading involves significant risk of loss and is not suitable for everyone. Past performance does not guarantee future results.";
export const COPY = {
  sub: "Access real-time market prices, interactive charts and market insights from an advanced trading platform.",
  heroCta: "Explore Live Markets",
  cta: "Open an Account",
  banner: "Ready to start trading?",
  bannerSub: "Open an account and explore the markets.",
  authTitle: "Create your account",
};
