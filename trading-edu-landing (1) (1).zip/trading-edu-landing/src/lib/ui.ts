export const card = "rounded-2xl border border-white/10 bg-surface p-6 transition hover:border-cyan-400/40 hover:shadow-glow";
export const fmt = (n: number, d: number) => n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
