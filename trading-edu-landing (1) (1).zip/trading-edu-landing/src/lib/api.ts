// Auth client for YOUR backend. (Market data no longer goes through here; see marketFeed.tsx.)
import { MODE } from "./config";
export const LIVE = MODE === "live";
const API_URL = ((import.meta.env.VITE_API_URL as string | undefined) ?? "").replace(/\/$/, "");
export class ApiError extends Error { constructor(public status: number, msg: string) { super(msg); } }
async function http<T>(path: string, init?: RequestInit): Promise<T> {
  if (!API_URL) throw new ApiError(0, "VITE_API_URL is not set.");
  const res = await fetch(API_URL + path, { credentials: "include", headers: { "Content-Type": "application/json" }, ...init });
  if (!res.ok) { let m = res.statusText; try { m = (await res.json()).message ?? m; } catch {} throw new ApiError(res.status, m); }
  return res.json();
}
type Creds = { email: string; password: string; acceptedRisk?: boolean };
const notConnected = () => new Promise<never>((_, rej) => setTimeout(() => rej(new Error("Sign-up is not connected to a backend yet.")), 400));
export const auth = {
  login: (b: Creds) => (LIVE ? http<unknown>("/auth/login", { method: "POST", body: JSON.stringify(b) }) : notConnected()),
  register: (b: Creds) => (LIVE ? http<unknown>("/auth/register", { method: "POST", body: JSON.stringify(b) }) : notConnected()),
};
