// Real market data: Binance public market-data endpoints (no API key). Crypto spot pairs only.
// Nothing here is simulated. If the feed fails, the UI says so and the LIVE badge goes off.
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
export type Market = { symbol: string; name: string; pair: string; dec: number };
export const MARKETS: Market[] = [
  { symbol: "BTCUSDT", name: "Bitcoin", pair: "BTC/USDT", dec: 2 },
  { symbol: "ETHUSDT", name: "Ethereum", pair: "ETH/USDT", dec: 2 },
  { symbol: "BNBUSDT", name: "BNB", pair: "BNB/USDT", dec: 2 },
  { symbol: "SOLUSDT", name: "Solana", pair: "SOL/USDT", dec: 2 },
  { symbol: "XRPUSDT", name: "XRP", pair: "XRP/USDT", dec: 4 },
];
export const REST = "https://data-api.binance.vision";
export const WS = "wss://data-stream.binance.vision";
export type Quote = { price: number; open: number; high: number; low: number };
export type Status = "connecting" | "live" | "reconnecting" | "offline";
type Ctx = { quotes: Record<string, Quote>; status: Status; lastUpdate: number | null; error: string };
const Market = createContext<Ctx>({ quotes: {}, status: "connecting", lastUpdate: null, error: "" });
export const useMarket = () => useContext(Market);
const STALE_MS = 15000;

export function MarketProvider({ children }: { children: ReactNode }) {
  const [quotes, setQuotes] = useState<Record<string, Quote>>({});
  const [status, setStatus] = useState<Status>(navigator.onLine ? "connecting" : "offline");
  const [lastUpdate, setLast] = useState<number | null>(null);
  const [error, setError] = useState("");
  const lastMsg = useRef(0);
  useEffect(() => {
    let ws: WebSocket | undefined, timer: ReturnType<typeof setTimeout> | undefined, retry = 0, dead = false;
    // Initial snapshot from the REST API (real 24h stats), so the table isn't empty while the socket opens.
    fetch(`${REST}/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(MARKETS.map((m) => m.symbol)))}`)
      .then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.json(); })
      .then((rows: any[]) => { if (dead) return; setQuotes((p) => { const n = { ...p }; rows.forEach((r) => { n[r.symbol] = n[r.symbol] ?? { price: +r.lastPrice, open: +r.openPrice, high: +r.highPrice, low: +r.lowPrice }; }); return n; }); setLast((t) => t ?? Date.now()); })
      .catch(() => !dead && setError("Could not load the latest prices."));
    const connect = () => {
      if (dead) return;
      if (!navigator.onLine) { setStatus("offline"); return; }
      setStatus(retry === 0 ? "connecting" : "reconnecting");
      const sock = new WebSocket(`${WS}/stream?streams=${MARKETS.map((m) => m.symbol.toLowerCase() + "@miniTicker").join("/")}`);
      ws = sock;
      sock.onopen = () => { lastMsg.current = Date.now(); };
      sock.onmessage = (e) => {
        try {
          const d = JSON.parse(e.data).data;
          if (!d || d.e !== "24hrMiniTicker") return;
          lastMsg.current = Date.now(); retry = 0;
          setQuotes((p) => ({ ...p, [d.s]: { price: +d.c, open: +d.o, high: +d.h, low: +d.l } }));
          setLast(Date.now()); setStatus("live"); setError("");
        } catch { /* ignore malformed frame */ }
      };
      sock.onclose = () => { if (dead || ws !== sock) return; setStatus("reconnecting"); timer = setTimeout(connect, Math.min(30000, 1000 * 2 ** retry++)); };
      sock.onerror = () => sock.close();
    };
    const restart = () => { clearTimeout(timer); const old = ws; ws = undefined; old?.close(); retry = 0; connect(); };
    const watchdog = setInterval(() => { if (ws && lastMsg.current && Date.now() - lastMsg.current > STALE_MS) { setStatus("reconnecting"); restart(); } }, 3000);
    const onOffline = () => { setStatus("offline"); setError("You appear to be offline."); };
    const onOnline = () => { setError(""); restart(); };
    addEventListener("offline", onOffline); addEventListener("online", onOnline);
    connect();
    return () => { dead = true; clearTimeout(timer); clearInterval(watchdog); removeEventListener("offline", onOffline); removeEventListener("online", onOnline); ws?.close(); };
  }, []);
  return <Market.Provider value={{ quotes, status, lastUpdate, error }}>{children}</Market.Provider>;
}
