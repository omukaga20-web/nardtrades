import { Route, Routes } from "react-router-dom";
import Nav from "./components/Nav";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
export default function App() {
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[60] focus:rounded-lg focus:bg-cyan-400 focus:px-4 focus:py-2 focus:text-navy">Skip to content</a>
      <Nav />
      <Routes>
        <Route path="/" element={<main id="main"><Home /></main>} />
        <Route path="/login" element={<Auth mode="login" />} />
        <Route path="/register" element={<Auth mode="register" />} />
        <Route path="*" element={<main id="main" className="px-4 py-24 text-center"><h1 className="text-2xl font-bold">Page not found</h1><p className="mt-2 text-slate-300">Add /privacy and /terms pages before launch.</p></main>} />
      </Routes>
      <Footer />
      <CookieBanner />
    </>
  );
}
