import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { Button } from "./Button";
type BIPE = Event & { prompt: () => Promise<void> };
const standalone = () => matchMedia("(display-mode: standalone)").matches || (navigator as any).standalone === true;
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent);
export default function InstallButton({ className = "" }: { className?: string }) {
  const [ev, setEv] = useState<BIPE | null>(null);
  const [hint, setHint] = useState(false);
  const [done, setDone] = useState(standalone());
  useEffect(() => {
    const onPrompt = (e: Event) => { e.preventDefault(); setEv(e as BIPE); };
    const onInstalled = () => { setDone(true); setEv(null); };
    addEventListener("beforeinstallprompt", onPrompt); addEventListener("appinstalled", onInstalled);
    return () => { removeEventListener("beforeinstallprompt", onPrompt); removeEventListener("appinstalled", onInstalled); };
  }, []);
  if (done || (!ev && !isIOS())) return null;
  const click = async () => { if (ev) { await ev.prompt(); setEv(null); } else setHint((h) => !h); };
  return (
    <div className={className}>
      <Button variant="outline" onClick={click} className="w-full gap-2"><Download className="h-4 w-4" aria-hidden />Install app</Button>
      {hint && <p role="note" className="mt-2 text-xs text-slate-300">On iPhone: tap the Share button in Safari, then “Add to Home Screen”.</p>}
    </div>
  );
}
