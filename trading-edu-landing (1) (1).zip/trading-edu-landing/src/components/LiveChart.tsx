import { useEffect, useRef, useState } from "react";
import { ColorType, createChart } from "lightweight-charts";
import { REST, WS } from "../lib/marketFeed";
// 1-minute candles: history from REST, then live updates from the kline WebSocket.
export default function LiveChart({ symbol, mode }: { symbol: string; mode: "candle" | "line" }) {
  const ref = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [conn, setConn] = useState(true);
  useEffect(() => {
    if (!ref.current) return;
    let dead = false, retry = 0, timer: ReturnType<typeof setTimeout> | undefined, ws: WebSocket | undefined;
    setState("loading"); setConn(true);
    const chart = createChart(ref.current, {
      autoSize: true,
      layout: { background: { type: ColorType.Solid, color: "transparent" }, textColor: "#94a3b8" },
      grid: { vertLines: { color: "rgba(255,255,255,.05)" }, horzLines: { color: "rgba(255,255,255,.05)" } },
      rightPriceScale: { borderVisible: false }, timeScale: { borderVisible: false, timeVisible: true, secondsVisible: false },
    });
    const s: any = mode === "candle"
      ? chart.addCandlestickSeries({ upColor: "#22d3ee", downColor: "#f87171", wickUpColor: "#22d3ee", wickDownColor: "#f87171", borderVisible: false })
      : chart.addLineSeries({ color: "#22d3ee", lineWidth: 2 });
    const point = (c: any) => (mode === "candle" ? c : { time: c.time, value: c.close });
    const open = () => {
      if (dead) return;
      const sock = new WebSocket(`${WS}/ws/${symbol.toLowerCase()}@kline_1m`); ws = sock;
      sock.onopen = () => { retry = 0; setConn(true); };
      sock.onmessage = (e) => { try { const k = JSON.parse(e.data).k; if (k) s.update(point({ time: Math.floor(k.t / 1000), open: +k.o, high: +k.h, low: +k.l, close: +k.c })); } catch { /* ignore */ } };
      sock.onclose = () => { if (dead || ws !== sock) return; setConn(false); timer = setTimeout(open, Math.min(30000, 1000 * 2 ** retry++)); };
      sock.onerror = () => sock.close();
    };
    fetch(`${REST}/api/v3/klines?symbol=${symbol}&interval=1m&limit=120`)
      .then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.json(); })
      .then((rows: any[]) => {
        if (dead) return;
        s.setData(rows.map((k) => point({ time: Math.floor(k[0] / 1000), open: +k[1], high: +k[2], low: +k[3], close: +k[4] })));
        chart.timeScale().fitContent(); setState("ready"); open();
      })
      .catch(() => !dead && setState("error"));
    return () => { dead = true; clearTimeout(timer); ws?.close(); chart.remove(); };
  }, [symbol, mode]);
  return (
    <div className="relative">
      <div ref={ref} className="h-72 w-full sm:h-96" role="img" aria-label={`Live ${symbol} price chart`} />
      {state === "loading" && <div className="absolute inset-0 animate-pulse rounded-xl bg-white/10" aria-label="Loading chart" />}
      {state === "error" && <p role="alert" className="absolute inset-0 grid place-items-center rounded-xl bg-navy/90 p-4 text-center text-sm text-amber-300">Chart data is unavailable right now. Check your connection and try another market.</p>}
      {state === "ready" && !conn && <p role="status" className="absolute right-2 top-2 rounded-lg bg-amber-400/15 px-2 py-1 text-xs text-amber-300">Chart reconnecting…</p>}
    </div>
  );
}
