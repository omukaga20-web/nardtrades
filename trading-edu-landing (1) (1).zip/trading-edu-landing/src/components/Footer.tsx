import { Link } from "react-router-dom";
import { BRAND, CONTACT_EMAIL, REGULATOR_LINE, RISK } from "../lib/config";
export default function Footer() {
  const l = "rounded hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300";
  return (
    <footer className="border-t border-white/10 bg-surface/50">
      <div className="mx-auto max-w-6xl space-y-6 px-4 py-10">
        <nav aria-label="Footer" className="flex flex-wrap gap-6 text-sm text-slate-300">
          <Link className={l} to="/privacy">Privacy</Link><Link className={l} to="/terms">Terms</Link>
          <a className={l} href="#support">Support</a><a className={l} href={`mailto:${CONTACT_EMAIL}`}>Contact</a>
        </nav>
        <div role="note" className="rounded-xl border border-amber-400/30 bg-amber-400/5 p-4 text-sm text-slate-200">
          <strong>Risk warning.</strong> {RISK}
          <p className="mt-2 text-slate-400">Regulatory status: {REGULATOR_LINE}</p>
        </div>
        <p className="text-xs text-slate-400">© {new Date().getFullYear()} {BRAND}. All rights reserved.</p>
      </div>
    </footer>
  );
}
