import { useEffect, useState } from "react";
import { Button } from "./Button";
const KEY = "cookie-consent";
export default function CookieBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => { try { if (!localStorage.getItem(KEY)) setShow(true); } catch { setShow(true); } }, []);
  const choose = (v: string) => { try { localStorage.setItem(KEY, v); } catch {} setShow(false); };
  if (!show) return null;
  return (
    <div role="dialog" aria-label="Cookie notice" className="fixed inset-x-3 bottom-[calc(0.75rem+env(safe-area-inset-bottom))] z-50 mx-auto flex max-w-xl flex-col gap-3 rounded-2xl border border-white/10 bg-surface p-4 shadow-xl sm:flex-row sm:items-center">
      <p className="text-sm text-slate-300">We use essential cookies, and analytics only if you allow them.</p>
      <div className="flex gap-2"><Button variant="outline" onClick={() => choose("essential")}>Essential only</Button><Button onClick={() => choose("all")}>Accept all</Button></div>
    </div>
  );
}
