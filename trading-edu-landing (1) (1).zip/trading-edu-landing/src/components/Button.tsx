import { Link } from "react-router-dom";
import type { ButtonHTMLAttributes, ReactNode } from "react";
const base = "inline-flex items-center justify-center rounded-xl px-5 py-2.5 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 focus-visible:ring-offset-2 focus-visible:ring-offset-navy disabled:cursor-not-allowed disabled:opacity-50";
const v = { solid: "bg-cyan-400 text-navy hover:bg-cyan-300 hover:shadow-glow", ghost: "text-slate-200 hover:bg-white/10", outline: "border border-white/20 text-slate-100 hover:bg-white/10" };
type V = keyof typeof v;
export function Button({ variant = "solid", className = "", ...p }: { variant?: V } & ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button className={`${base} ${v[variant]} ${className}`} {...p} />;
}
export function LinkButton({ to, variant = "solid", className = "", children, onClick }: { to: string; variant?: V; className?: string; children: ReactNode; onClick?: () => void }) {
  const cls = `${base} ${v[variant]} ${className}`;
  return to.startsWith("#") ? <a href={to} className={cls} onClick={onClick}>{children}</a> : <Link to={to} className={cls} onClick={onClick}>{children}</Link>;
}
