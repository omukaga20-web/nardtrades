import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { TESTIMONIALS, type Testimonial } from "../lib/config";
import { card } from "../lib/ui";
export default function Testimonials({ items = TESTIMONIALS }: { items?: Testimonial[] }) {
  const ref = useRef<HTMLUListElement>(null);
  if (!items.length) return null;
  const by = (d: number) => ref.current?.scrollBy({ left: d * 320, behavior: "smooth" });
  return (
    <section aria-labelledby="t-h" className="mx-auto max-w-6xl px-4 py-16">
      <div className="mb-6 flex items-center justify-between">
        <h2 id="t-h" className="text-2xl font-bold sm:text-3xl">What learners say</h2>
        <div className="flex gap-2">
          <button aria-label="Previous" onClick={() => by(-1)} className="rounded-full border border-white/15 p-2 hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-cyan-300"><ChevronLeft /></button>
          <button aria-label="Next" onClick={() => by(1)} className="rounded-full border border-white/15 p-2 hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-cyan-300"><ChevronRight /></button>
        </div>
      </div>
      <ul ref={ref} className="flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2">
        {items.map((t, i) => (
          <li key={i} className={`${card} w-80 shrink-0 snap-start`}>
            <blockquote className="text-slate-200">“{t.quote}”</blockquote>
            <p className="mt-4 text-sm text-slate-400">{t.name}, {t.location}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
