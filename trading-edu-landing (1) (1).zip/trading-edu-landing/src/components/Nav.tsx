import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, TrendingUp, X } from "lucide-react";
import { LinkButton } from "./Button";
import InstallButton from "./InstallButton";
import { BRAND } from "../lib/config";
export default function Nav() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="sticky top-0 z-50 pt-[env(safe-area-inset-top)] border-b border-white/10 bg-navy/85 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2 rounded-lg text-lg font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300">
          <TrendingUp className="h-5 w-5 text-cyan-400" aria-hidden /> {BRAND}
        </Link>
        <div className="hidden items-center gap-2 md:flex">
          <InstallButton />
          <LinkButton to="/login" variant="ghost">Log in</LinkButton>
          <LinkButton to="/register">Get Started</LinkButton>
        </div>
        <button className="rounded-lg p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 md:hidden" aria-label="Toggle menu" aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      {open && (
        <div id="mobile-menu" className="flex flex-col gap-2 border-t border-white/10 p-4 md:hidden">
          <LinkButton to="/login" variant="outline" onClick={close}>Log in</LinkButton>
          <LinkButton to="/register" onClick={close}>Get Started</LinkButton>
          <InstallButton />
        </div>
      )}
    </header>
  );
}
