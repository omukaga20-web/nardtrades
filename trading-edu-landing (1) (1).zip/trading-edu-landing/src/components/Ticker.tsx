import { MARKETS, useMarket } from "../lib/marketFeed";
import { fmt } from "../lib/ui";
export default function Ticker() {
  const { quotes, status } = useMarket();
  const rows = MARKETS.filter((m) => quotes[m.symbol]);
  return (
    <section aria-label="Price ticker" className="border-y border-white/10 bg-surface/60">
      <p className="px-4 py-1 text-center text-xs text-slate-400">{status === "live" ? "Live prices from Binance public market data." : "Prices may be delayed or unavailable."}</p>
      {!rows.length ? <div className="mx-4 mb-3 h-8 animate-pulse rounded-lg bg-white/10" /> : (
        <div className="overflow-hidden pb-3">
          <ul className="flex w-max animate-marquee gap-10 px-5 hover:[animation-play-state:paused] motion-reduce:animate-none">
            {[...rows, ...rows].map((m, i) => { const k = quotes[m.symbol]; const pct = ((k.price - k.open) / k.open) * 100; return (
              <li key={i} className="flex items-center gap-2 text-sm" aria-hidden={i >= rows.length}>
                <span className="font-semibold">{m.pair}</span><span className="text-slate-300">{fmt(k.price, m.dec)}</span>
                <span className={pct >= 0 ? "text-cyan-400" : "text-red-400"}>{pct >= 0 ? "▲" : "▼"} {Math.abs(pct).toFixed(2)}%</span>
              </li>); })}
          </ul>
        </div>)}
    </section>
  );
}
