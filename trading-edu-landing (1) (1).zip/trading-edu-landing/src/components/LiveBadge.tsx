import { useMarket } from "../lib/marketFeed";
// "LIVE" shows only while real ticks are arriving. Otherwise the true state is shown.
export default function LiveBadge() {
  const { status, lastUpdate } = useMarket();
  const live = status === "live";
  const label = { connecting: "Connecting…", live: "LIVE", reconnecting: "Reconnecting…", offline: "Offline" }[status];
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs">
      <span role="status" className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-semibold ${live ? "bg-cyan-400/15 text-cyan-300" : "bg-amber-400/15 text-amber-300"}`}>
        <span className={`h-2 w-2 rounded-full ${live ? "animate-pulse bg-cyan-400 motion-reduce:animate-none" : "bg-amber-400"}`} aria-hidden />{label}
      </span>
      {lastUpdate && <span className="text-slate-400">Last updated {new Date(lastUpdate).toLocaleTimeString()}</span>}
    </div>
  );
}
