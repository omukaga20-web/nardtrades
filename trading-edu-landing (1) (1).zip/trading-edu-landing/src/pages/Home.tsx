import Hero from "../sections/Hero";
import Ticker from "../components/Ticker";
import LiveMarkets from "../sections/LiveMarkets";
import Features from "../sections/Features";
import Steps from "../sections/Steps";
import Stats from "../sections/Stats";
import Testimonials from "../components/Testimonials";
import CtaBanner from "../sections/CtaBanner";
import AppSection from "../sections/AppSection";
import { MarketProvider } from "../lib/marketFeed";
export default function Home() {
  return <MarketProvider><Hero /><Ticker /><LiveMarkets /><Features /><Steps /><Stats /><Testimonials /><CtaBanner /><AppSection /></MarketProvider>;
}
