import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "react-router-dom";
import { Button } from "../components/Button";
import { COPY, POST_AUTH_URL, RISK } from "../lib/config";
import { auth, LIVE } from "../lib/api";
const login = z.object({ email: z.string().email("Enter a valid email"), password: z.string().min(8, "Use at least 8 characters") });
const register = login.extend({ confirm: z.string(), terms: z.literal(true, { errorMap: () => ({ message: "Accept the terms and risk warning to continue" }) }) })
  .refine((d) => d.password === d.confirm, { path: ["confirm"], message: "Passwords do not match" });
type F = { email: string; password: string; confirm?: string; terms?: boolean };
export default function Auth({ mode }: { mode: "login" | "register" }) {
  const reg = mode === "register";
  const { register: r, handleSubmit, formState: { errors, isSubmitting } } = useForm<F>({ resolver: zodResolver(reg ? register : login) as any });
  const [done, setDone] = useState(false);
  const [serverErr, setServerErr] = useState("");
  const onSubmit = async (f: F) => {
    setServerErr("");
    try { await (reg ? auth.register({ email: f.email, password: f.password, acceptedRisk: true }) : auth.login({ email: f.email, password: f.password })); if (LIVE) window.location.href = POST_AUTH_URL; else setDone(true); }
    catch (e) { setServerErr(e instanceof Error ? e.message : "Something went wrong. Try again."); }
  };
  const input = "mt-1 w-full rounded-xl border border-white/15 bg-navy px-3 py-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300";
  const err = (m?: string, id?: string) => m && <p id={id} role="alert" className="mt-1 text-sm text-red-400">{m}</p>;
  return (
    <main id="main" className="mx-auto max-w-md px-4 py-16">
      <h1 className="text-3xl font-bold">{reg ? COPY.authTitle : "Log in"}</h1>
      <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4 rounded-2xl border border-white/10 bg-surface p-6">
        <div><label htmlFor="email">Email</label><input id="email" type="email" autoComplete="email" aria-invalid={!!errors.email} className={input} {...r("email")} />{err(errors.email?.message)}</div>
        <div><label htmlFor="pw">Password</label><input id="pw" type="password" autoComplete={reg ? "new-password" : "current-password"} aria-invalid={!!errors.password} className={input} {...r("password")} />{err(errors.password?.message)}</div>
        {reg && <>
          <div><label htmlFor="cf">Confirm password</label><input id="cf" type="password" autoComplete="new-password" className={input} {...r("confirm")} />{err(errors.confirm?.message)}</div>
          <div><label className="flex gap-2 text-sm text-slate-300"><input type="checkbox" className="mt-1" {...r("terms")} /><span>I accept the Terms and understand: {RISK}</span></label>{err(errors.terms?.message)}</div>
        </>}
        <Button type="submit" disabled={isSubmitting} className="w-full">{isSubmitting ? "Please wait…" : reg ? "Create account" : "Log in"}</Button>
        {serverErr && <p role="alert" className="text-sm text-red-400">{serverErr}</p>}
        {done && <p role="status" className="text-sm text-amber-300">Form is valid, but sign-up is not connected to a backend yet. Set VITE_MODE=live and VITE_API_URL.</p>}
      </form>
      <p className="mt-4 text-sm text-slate-400">{reg ? <>Have an account? <Link className="text-cyan-300 underline" to="/login">Log in</Link></> : <>New here? <Link className="text-cyan-300 underline" to="/register">Create an account</Link></>}</p>
    </main>
  );
}
