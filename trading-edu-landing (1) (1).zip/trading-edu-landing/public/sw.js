// Caches the app shell only. Market data (cross-origin) and backend API calls are never intercepted or cached,
// so prices are always fetched live and can never be served stale from this cache.
const V = "pipnex-v1";
const SHELL = ["/", "/offline.html", "/icons/icon-192.png"];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(V).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== V).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin) return;
  if (r.mode === "navigate") {
    e.respondWith(
      fetch(r).then((res) => { const cp = res.clone(); caches.open(V).then((c) => c.put("/", cp)); return res; })
        .catch(() => caches.match("/").then((m) => m || caches.match("/offline.html")))
    );
    return;
  }
  if (u.pathname.startsWith("/assets/") || u.pathname.startsWith("/icons/")) {
    e.respondWith(caches.match(r).then((m) => m || fetch(r).then((res) => { const cp = res.clone(); caches.open(V).then((c) => c.put(r, cp)); return res; })));
  }
});
