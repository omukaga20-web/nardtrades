# Pipnex landing page: live market data

    cp .env.example .env
    npm install && npm run dev

## Live market data
- Prices: Binance public market-data WebSocket (`miniTicker`) plus a REST snapshot. Charts: 1-minute klines (REST history, then WebSocket updates). No API key, no simulated values anywhere in the code.
- The **LIVE** badge (hero and Live markets section) shows only while ticks are arriving. If nothing arrives for 15 s it switches to "Reconnecting…", and the table warns that prices may be out of date.
- "Last updated" is the time the last real tick was received in the browser.
- Handled: failed snapshot or kline requests, socket drops (exponential backoff, max 30 s), stalled feeds (watchdog), browser going offline/online.
- Coverage: crypto spot pairs only (edit `MARKETS` in `src/lib/marketFeed.tsx`). Gold, forex and stocks need a licensed provider (for example Twelve Data, Finnhub or your broker). Call it from YOUR backend so the API key stays secret, then add a second feed that returns the same `Quote` shape.
- Check Binance's market-data terms and rate limits before commercial use, or switch to a licensed provider.
- Binance endpoints can be blocked in some regions. If a visitor's network blocks them, they see the offline state, never fake prices.

## Auth backend (optional, unchanged)
POST /auth/login `{email,password}` and POST /auth/register `{email,password,acceptedRisk:true}`; return `{message}` on errors; use httpOnly Secure SameSite cookies, CSRF protection and rate limiting. Enabled with `VITE_MODE=live` and `VITE_API_URL`.

## Placeholders
src/lib/config.ts: BRAND, REGULATOR_LINE, CONTACT_EMAIL, STATS, TESTIMONIALS. Also fee schedule and payment methods (Features.tsx, Steps.tsx), /privacy and /terms pages, public/og.png.

## Before going live
- Fill in REGULATOR_LINE with a real licence, or partner with a licensed broker.
- Remove hero chips you cannot prove ("100+ markets" is not true while only 5 markets are listed).
- Keep the risk warning visible. No guaranteed-return wording.

## Phone version (installable PWA)
Same site, installable on Android, iPhone and desktop. Needs HTTPS (or localhost) and a production build: `npm run build && npm run preview`.
- Android/Chrome: an "Install app" button appears in the nav. iPhone: the same button shows the "Share, then Add to Home Screen" steps.
- `public/sw.js` caches only the app shell. Market data and API calls are never cached, so prices are never stale; offline, the app opens and shows the Offline state.
- Edit `public/manifest.webmanifest` for name and colours, and replace the icons in `public/icons/` with your logo (192, 512, and a padded 512 maskable).
- Bump `V` in `public/sw.js` on releases that change cached files.
- Not included: push notifications, app-store listing. For store apps, wrap with Capacitor or rebuild in Expo.
