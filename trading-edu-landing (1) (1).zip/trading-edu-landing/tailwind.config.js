export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { navy: "#0B1020", surface: "#121A33" },
    fontFamily: { sans: ["Inter", "system-ui", "sans-serif"] },
    boxShadow: { glow: "0 0 32px rgba(34,211,238,.18)" },
    keyframes: { marquee: { "0%": { transform: "translateX(0)" }, "100%": { transform: "translateX(-50%)" } } },
    animation: { marquee: "marquee 45s linear infinite" },
  } },
  plugins: [],
};
